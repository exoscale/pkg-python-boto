.. _ref-index:

=============
API Reference
=============

.. toctree::
   :maxdepth: 4

   boto
   beanstalk
   cloudformation
   cloudfront
   cloudsearch
   contrib
   dynamodb
   ec2
   ecs
   emr
   file
   fps
   glacier
   gs
   iam
   kinesis
   manage
   mturk
   mws
   pyami
   rds
   redshift
   route53
   s3
   sdb
   services
   ses
   sns
   sqs
   sts
   swf
   vpc

