.. ref-cloudformation

==============
cloudformation
==============

boto.cloudformation
-------------------

.. automodule:: boto.cloudformation
   :members:   
   :undoc-members:

boto.cloudformation.connection
------------------------------

.. automodule:: boto.cloudformation.connection
   :members:
   :undoc-members:

boto.cloudformation.stack
-------------------------

.. automodule:: boto.cloudformation.stack
   :members:
   :undoc-members:

boto.cloudformation.template
----------------------------

.. automodule:: boto.cloudformation.template
   :members:
   :undoc-members:

